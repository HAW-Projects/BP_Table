#include <atmel_start.h>
#include <util/delay.h>



int main(void)
{
	
	uint8_t key_status = 0;

	/* Initializes MCU, drivers and middleware */
	atmel_start_init();


	cpu_irq_enable(); /* Global Interrupt Enable */

	


	/* Replace with your application code */
	while (1) {
			touch_process();
				IR_LED_set_level(0);

			
			key_status = get_sensor_state(0) & KEY_TOUCHED_MASK;
			if (0u != key_status) {
				IR_LED_set_level(1);
				} else {
			}
			key_status = get_sensor_state(1) & KEY_TOUCHED_MASK;
						if (0u != key_status) {
							IR_LED_set_level(1);
							} else {
						}
									key_status = get_sensor_state(2) & KEY_TOUCHED_MASK;
									if (0u != key_status) {
										IR_LED_set_level(1);
										} else {
									}
			_delay_ms(100);
	}
}
